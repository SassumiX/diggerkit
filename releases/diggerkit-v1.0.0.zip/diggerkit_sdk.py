"""
Golddigger DiggerKit SDK — 完全开源免费 (MIT License)
========================================================

这是 Golddigger 官方的开源 Python SDK.
免费试用 10 次/天 云端 API 调用额度. 用完或想升级 → https://golddigger.gold/

快速开始:
    pip install requests
    python diggerkit_sdk.py --query "modular steel buildings" --country UAE

或者导入到自己的代码:
    from diggerkit_sdk import GolddiggerClient
    c = GolddiggerClient(api_key="gd_xxx")
    leads = c.search("modular buildings", country="UAE")
"""

import os
import csv
import json
import time
import argparse
import requests
from typing import List, Dict, Optional, Tuple

__version__ = "1.0.0"
DEFAULT_BASE = "https://golddigger.gold"


class GolddiggerClient:
    """Golddigger API 客户端"""

    def __init__(self, api_key: str, base_url: str = DEFAULT_BASE):
        if not api_key:
            raise ValueError("api_key 不能为空 (从 https://golddigger.gold/ui/ 获取)")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        self.session.headers.update({
            "X-API-KEY": api_key,
            "Content-Type": "application/json",
            "User-Agent": f"Golddigger-DiggerKit/{__version__}",
        })

    def search(self, query: str, country: str = "", limit: int = 50) -> Tuple[List[Dict], int]:
        """搜索 B2B 买家

        Args:
            query: 关键词, 如 "modular steel buildings"
            country: 国家代码 (ISO 3166-1 alpha-2), 如 "UAE" / "US" / "DE"
            limit: 返回数量上限 (默认 50, 最大 500)

        Returns:
            (leads, total_found): leads 列表 + 总命中数
        """
        resp = self.session.post(
            f"{self.base_url}/api/search",
            json={"query": query, "country": country, "limit": limit},
            timeout=30,
        )
        if resp.status_code == 429:
            raise RuntimeError("配额用完, 等明天重置或升级方案 https://golddigger.gold/")
        resp.raise_for_status()
        data = resp.json()
        return data.get("leads", []), data.get("total_found", 0)

    def distill(self, product_desc: str, max_keywords: int = 30) -> List[str]:
        """蒸馏: 从产品描述提取搜索关键词

        Args:
            product_desc: 产品描述文本
            max_keywords: 最大关键词数

        Returns:
            关键词列表
        """
        resp = self.session.post(
            f"{self.base_url}/api/distill",
            json={"text": product_desc, "max_keywords": max_keywords},
            timeout=30,
        )
        resp.raise_for_status()
        return resp.json().get("keywords", [])

    def match_leads(self, keywords: List[str], country: str = "") -> List[Dict]:
        """根据关键词匹配真实买家 leads"""
        resp = self.session.post(
            f"{self.base_url}/api/match",
            json={"keywords": keywords, "country": country},
            timeout=30,
        )
        resp.raise_for_status()
        return resp.json().get("leads", [])

    def whoami(self) -> Dict:
        """查询当前账户信息 (plan / quota / credits)"""
        resp = self.session.get(f"{self.base_url}/api/tenants/me", timeout=10)
        resp.raise_for_status()
        return resp.json().get("tenant", {})


def save_leads_to_csv(leads: List[Dict], filename: str = "leads.csv") -> str:
    """保存 leads 到 CSV 文件 (utf-8, Excel 友好)"""
    if not leads:
        print(f"⚠️  没有 leads 可保存")
        return filename
    path = os.path.join(os.path.dirname(__file__) or ".", filename)
    keys = ["company", "country", "contact", "email", "phone", "website", "score"]
    write_header = not os.path.exists(path) or os.path.getsize(path) == 0
    with open(path, "a", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=keys, extrasaction="ignore")
        if write_header:
            w.writeheader()
        for lead in leads:
            w.writerow(lead)
    print(f"✅ 已保存 {len(leads)} 条 leads → {filename}")
    return path


# ── CLI ──

def main():
    parser = argparse.ArgumentParser(description="Golddigger DiggerKit CLI")
    parser.add_argument("--api-key", default=os.environ.get("GOLDDIGGER_API_KEY"),
                        help="你的 API key (默认读环境变量 GOLDDIGGER_API_KEY)")
    parser.add_argument("--query", required=True, help="搜索关键词, 如 'modular steel buildings'")
    parser.add_argument("--country", default="", help="国家代码, 如 UAE/US/DE")
    parser.add_argument("--limit", type=int, default=50, help="返回数量 (默认 50, 最大 500)")
    parser.add_argument("--out", default="leads.csv", help="输出 CSV 文件")
    args = parser.parse_args()

    api_key = args.api_key
    if not api_key:
        print("❌ 缺少 API key")
        print("   选项 1: --api-key gd_xxx")
        print("   选项 2: export GOLDDIGGER_API_KEY=gd_xxx")
        print("   选项 3: 到 https://golddigger.gold/ui/ 注册获取")
        return 1

    client = GolddiggerClient(api_key=api_key)

    # 显示账户信息
    try:
        me = client.whoami()
        print(f"👤 账户: {me.get('name')} ({me.get('email')})")
        print(f"📦 方案: {me.get('plan')} | 今日配额: {me.get('quota_used')}/{me.get('quota_daily')}")
        print()
    except Exception as e:
        print(f"⚠️  无法获取账户信息: {e}\n")

    # 搜索
    print(f"🔍 搜索: '{args.query}' (国家: {args.country or 'ALL'}, 上限: {args.limit})")
    try:
        leads, total = client.search(args.query, args.country, args.limit)
    except Exception as e:
        print(f"❌ 搜索失败: {e}")
        return 1

    print(f"📊 找到 {total} 个买家, 返回 {len(leads)} 条\n")

    if not leads:
        print("💡 建议:")
        print("   - 换一个关键词试试")
        print("   - 放宽国家限制 (去掉 --country)")
        print("   - 用 --limit 提高上限")
        return 0

    # 打印预览
    for i, lead in enumerate(leads[:10], 1):
        score = lead.get("score", "—")
        company = lead.get("company", "—")
        country = lead.get("country", "—")
        contact = lead.get("contact") or "—"
        email = lead.get("email") or "—"
        print(f"  {i:>3}. [{score}分] {company}")
        print(f"       🌍 {country} | 👤 {contact} | ✉️  {email}")

    if len(leads) > 10:
        print(f"  ... 还有 {len(leads) - 10} 条, 见 CSV")

    # 保存
    save_leads_to_csv(leads, args.out)
    return 0


if __name__ == "__main__":
    exit(main())