# Golddigger DiggerKit (Python)

开源 Python SDK + 工具箱 — B2B 海外买家挖掘

## 快速开始

```bash
pip install requests
python diggerkit_sdk.py --query "modular steel buildings" --country UAE
```

或者导入到自己的代码:

```python
from diggerkit_sdk import GolddiggerClient
c = GolddiggerClient(api_key="gd_xxx")
leads = c.search("modular buildings", country="UAE")
```

## 工具箱 (diggerkit_tools.py)

集成 Keenable 搜索 + Firecrawl 抓取 + Golddigger 评分

```python
from diggerkit_tools import keenable_search, firecrawl_scrape
```

## License

MIT
