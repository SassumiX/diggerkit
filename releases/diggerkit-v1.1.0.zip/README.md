# Golddigger DiggerKit v1.1.0

开源 Python SDK + CLI for https://golddigger.gold (MIT License)

## v1.1 新增 (2026-10-08)

### AI Agent 模式 (PAI 管理)

租客可以授权自己的 AI Agent 帮他用 API, 配额独立管理 + 审计:

```python
from diggerkit_sdk import AgentTokenClient
a = AgentTokenClient(agent_token="agt_xxx")

# 预检 (不发请求, 只查)
status = a.check_quota(country="AE")
if not status["allowed"]:
    print(f"拒绝: {status.get('reason')}")

# 调 search (一次扣 1 quota, 写审计)
result = a.search("smart lock", country="AE", limit=20)
print(f"拿到 {result['count']} 条, 剩 {result['quota_remaining']}/{result['quota_limit']}")
```

### 异常体系

- `QuotaExhausted` 配额用完
- `CountryBlocked` 国家不在授权范围
- `IndustryBlocked` 行业不在授权范围
- `TokenRevoked` Agent 授权被撤销
- `InvalidToken` token 无效

## 传统 API key 模式 (v1.0)

```python
from diggerkit_sdk import GolddiggerClient
c = GolddiggerClient(api_key="gd_xxx")
leads, total = c.search("modular steel buildings", country="UAE")
```

## CLI

```bash
# 传统模式
python diggerkit_sdk.py --api-key gd_xxx --query "smart lock" --country UAE

# Agent 模式
python diggerkit_sdk.py --agent-token agt_xxx --query "smart lock" --country AE
```

## 4 个文件

- `diggerkit_sdk.py` (主 SDK, 引入它就行)
- `diggerkit_tools.py` (高级工具, 可选)
- `sample_leads.csv` (示例输出)
- `README.md` (本文档)

MIT License
