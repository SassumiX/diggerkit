"""
Golddigger × DiggerKit 工具箱
集成 Keenable 搜索 + Firecrawl 抓取 + Golddigger 存储
"""

import os
import httpx
import asyncio
from typing import List, Dict, Optional
from golddigger_db import store_lead, get_conn
from golddigger_crawler import scrape_website, extract_emails, extract_phone
from golddigger_score import score_leads

# ============== Keenable MCP ==============
KEENABLE_API_KEY = os.getenv("KEENABLE_API_KEY", "")
KEENABLE_MCP_URL = "https://api.keenable.ai/mcp"

HEADERS = {
    "Content-Type": "application/json",
    "Accept": "application/json, text/event-stream",
    "X-API-Key": KEENABLE_API_KEY
}


async def keenable_rpc(method: str, params: dict) -> dict:
    """发送 JSON-RPC 请求到 Keenable MCP"""
    async with httpx.AsyncClient(timeout=60) as client:
        resp = await client.post(
            KEENABLE_MCP_URL,
            headers=HEADERS,
            json={"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
        )
        data = resp.json()
        if "error" in data:
            raise Exception(data["error"]["message"])
        return data.get("result", {})


async def search_with_keenable(query: str, max_results: int = 10) -> List[Dict]:
    """使用 Keenable 搜索网页"""
    result = await keenable_rpc(
        "tools/call",
        {"name": "search_web_pages", "arguments": {"query": query, "max_results": max_results}}
    )
    results = result.get("content", [])
    leads = []
    for item in results:
        if isinstance(item, dict) and item.get("type") == "text":
            url = item.get("url", "")
            snippet = item.get("snippets", "")
            leads.append({
                "website": url,
                "source_url": url,
                "snippet": snippet[:500],
                "source": "keenable"
            })
    return leads


async def fetch_with_keenable(url: str, prompt: str = "") -> str:
    """使用 Keenable 抓取页面内容"""
    args = {"url": url}
    if prompt:
        args["prompt"] = prompt
    result = await keenable_rpc(
        "tools/call",
        {"name": "fetch_page_content", "arguments": args}
    )
    content = result.get("content", [])
    if isinstance(content, list):
        for item in content:
            if isinstance(item, dict) and item.get("type") == "text":
                return item.get("text", "")
    return str(content)


# ============== Golddigger Pipeline ==============
async def mine_leads_pipeline(
    query: str,
    country: str = "",
    industry: str = "",
    limit: int = 10,
    tenant_id: int = None
) -> List[Dict]:
    """
    完整挖客 pipeline:
    1. Keenable 搜索
    2. Firecrawl 抓取详情
    3. 提取联系方式
    4. 评分
    5. 存入数据库
    """
    print(f"[DiggerKit] 搜索: {query} ({country})")
    
    # 1. Keenable 搜索
    search_results = await search_with_keenable(f"{query} {country}".strip(), max_results=limit)
    print(f"[DiggerKit] Keenable 找到 {len(search_results)} 条结果")
    
    leads = []
    for item in search_results:
        url = item.get("website", "")
        if not url:
            continue
        
        # 2. Firecrawl 抓取
        print(f"[DiggerKit] 抓取: {url}")
        scraped = scrape_website(url)
        
        if scraped.get("success"):
            content = scraped.get("content", "")
            metadata = scraped.get("metadata", {})
            
            # 3. 提取信息
            emails = extract_emails(content)
            phones = extract_phone(content)
            
            lead = {
                "company": metadata.get("title", "") or item.get("snippet", "")[:50],
                "website": url,
                "email": emails[0] if emails else "",
                "phone": phones[0] if phones else "",
                "country": country,
                "industry": industry or metadata.get("description", "")[:100],
                "source": "keenable+firecrawl",
                "source_url": url,
                "products": content[:200],
                "tier": "warm",
                "score": 50
            }
            
            # 4. 评分
            if lead["email"]:
                lead["score"] = 70
                lead["tier"] = "hot"
            
            leads.append(lead)
            print(f"  ✓ {lead['company'][:30]} | {lead['email']} | Score: {lead['score']}")
            
            # 5. 存入数据库
            if tenant_id:
                try:
                    store_lead(tenant_id, lead)
                except Exception as e:
                    print(f"  ✗ 存储失败: {e}")
        
        await asyncio.sleep(0.5)  # 礼貌延迟
    
    # 6. 统一评分
    if leads:
        leads = score_leads(leads)
    
    print(f"[DiggerKit] 完成! 共 {len(leads)} 条线索")
    return leads


# ============== 工具函数 ==============
def get_stats() -> dict:
    """获取数据库统计"""
    conn = get_conn()
    cur = conn.execute("SELECT COUNT(*), AVG(score) FROM leads")
    row = cur.fetchone()
    return {
        "total_leads": row[0] or 0,
        "avg_score": round(row[1] or 0, 1)
    }


if __name__ == "__main__":
    # 测试
    print("=== DiggerKit 工具箱测试 ===")
    print(f"Keenable: {'✓' if KEENABLE_API_KEY else '✗'}")
    print(f"FIRECRAWL: {'✓' if os.getenv('FIRECRAWL_API_KEY') else '✗'}")
    
    async def test():
        leads = await mine_leads_pipeline("modular building", "Saudi Arabia", limit=3)
        for lead in leads:
            print(f"  [{lead['score']}] {lead['company'][:40]} | {lead['email']}")
    
    asyncio.run(test())
